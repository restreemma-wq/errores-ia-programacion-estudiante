# Análisis de solicitudes de programación a asistentes de IA

Análisis estadístico descriptivo de errores y solicitudes de programación realizadas a asistentes de inteligencia artificial (ChatGPT, Claude, Copilot y Gemini) por estudiantes universitarios.

## Contenido

- `datos/Base_datos_IA_programacion_filtrada.xlsx`: base de datos filtrada (100 registros, 14 variables).
  - **Base de datos:** datos depurados.
  - **Diccionario:** descripción y tipo de cada variable.
  - **Estadísticos:** media, mediana, moda, media geométrica, media armónica, rango, varianza, desviación estándar y coeficiente de variación.
  - **Frecuencias:** tablas de frecuencia de las variables categóricas.
  - **Variables descartadas:** justificación de las variables eliminadas.

## Notas metodológicas

- Varianza y desviación estándar muestrales (n-1).
- Media geométrica aplicada a *Factor de mejora* y media armónica a *Velocidad (palabras/seg)*.
